public class Lazy {
    public static void main(String[] args) {
        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                for (int k = -1; k <= 1; k++) {
                    if (i != 0 || j != 0 || k != 0) {
                        System.out.printf(
                                "execute positioned ~%d ~%d ~%d if blocks ~ ~ ~ ~ ~ ~ 20000016 0 20000016 all run function vimi:check_duribility%n",
                                i, j, k);
                    }
                }
            }
        }
    }
}